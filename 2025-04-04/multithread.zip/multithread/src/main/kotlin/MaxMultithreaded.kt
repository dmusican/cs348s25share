/**
 * Find the max of the elements of an array.
 */
fun maxMultiThreaded(arr: List<Double>, numThreads: Int): Double {
    return 0.0
}
